import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import './App.css';

function App() {
  const [files, setFiles] = useState([]);
  const [uploadMessage, setUploadMessage] = useState('');
  const [query, setQuery] = useState('');
  const [ragAnswer, setRagAnswer] = useState('');
  const [normalAnswer, setNormalAnswer] = useState('');

  // 드래그 앤 드롭 핸들러
  const onDrop = useCallback((acceptedFiles) => {
    setFiles((prevFiles) => [...prevFiles, ...acceptedFiles]); // 기존 파일과 추가 파일을 합쳐서 상태 업데이트
    handleUpload(acceptedFiles);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'text/csv': ['.csv'], 'application/pdf': ['.pdf'], 'text/plain': ['.txt'] }
  });

  // 파일 업로드 API 호출
  const handleUpload = async (files) => {
    const formData = new FormData();
    files.forEach(file => {
      formData.append('file', file);
    });

    try {
      const response = await fetch('http://localhost:5000/api/upload', {
        method: 'POST',
        body: formData,
      });
      if (!response.ok) {
        const errText = await response.text();
        throw new Error(errText);
      }
      const data = await response.json();
      setUploadMessage(data.message || '파일 업로드 성공!');
    } catch (error) {
      console.error('파일 업로드 실패:', error);
      setUploadMessage('파일 업로드 실패: ' + error.message);
    }
  };

  // RAG 방식 질문 제출 API 호출 (/api/answer)
  const handleRagQuerySubmit = async (e) => {
    e.preventDefault();
    if (!query) {
      setRagAnswer("질문을 입력하세요.");
      return;
    }
    try {
      const response = await fetch('http://localhost:5000/api/answer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query }),
      });
      if (!response.ok) {
        const errText = await response.text();
        throw new Error(errText);
      }
      const data = await response.json();
      setRagAnswer(data.answer || "답변이 없습니다.");
    } catch (error) {
      console.error('RAG 답변 생성 실패:', error);
      setRagAnswer("RAG 답변 생성 실패: " + error.message);
    }
  };

  // 일반 gemma2:2b 방식 질문 제출 API 호출 (/api/normal)
  const handleNormalQuerySubmit = async (e) => {
    e.preventDefault();
    if (!query) {
      setNormalAnswer("질문을 입력하세요.");
      return;
    }
    try {
      const response = await fetch('http://localhost:5000/api/normal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query }),
      });
      if (!response.ok) {
        const errText = await response.text();
        throw new Error(errText);
      }
      const data = await response.json();
      setNormalAnswer(data.answer || "답변이 없습니다.");
    } catch (error) {
      console.error('일반 답변 생성 실패:', error);
      setNormalAnswer("일반 답변 생성 실패: " + error.message);
    }
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>토마토 RAG 질문 응답 시스템😊</h1>
        <p>파일을 드래그 앤 드롭하거나 클릭하여 선택하세요!</p>
      </header>

      <section className="upload-section">
        <div {...getRootProps({ className: 'dropzone' })}>
          <input {...getInputProps()} />
          {isDragActive ? (
            <p>드래그 중... 파일을 놓으세요! 🚀</p>
          ) : (
            <p>여기에 CSV, TXT, PDF 파일을 드롭하세요.</p>
          )}
        </div>
        {files.length > 0 && (
          <div className="file-list">
            <h3>업로드된 파일 목록:</h3>
            <ul>
              {files.map((file, index) => (
                <li key={index}>{file.name}</li> // 여러 파일을 표시하도록 함
              ))}
            </ul>
          </div>
        )}
        {uploadMessage && <p className="upload-message">{uploadMessage}</p>}
      </section>

      <section className="query-section">
        <h2>질문 입력</h2>
        <form onSubmit={handleRagQuerySubmit}>
          <textarea 
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="여기에 질문을 입력하세요..."
            rows="4"
          />
          <div className="button-group">
            <button type="submit">RAG 방식 질문하기</button>
            <button type="button" onClick={handleNormalQuerySubmit}>
              일반 답변 질문하기
            </button>
          </div>
        </form>
        <div className="answers">
          <div className="answer-box">
            <h2>RAG 방식 답변:</h2>
            <p>{ragAnswer}</p>
          </div>
          <div className="answer-box">
            <h2>일반 답변 (gemma2:2b):</h2>
            <p>{normalAnswer}</p>
          </div>
        </div>
      </section>
    </div>
  );
}

export default App;
