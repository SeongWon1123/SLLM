import React from "react";
import ReactDOM from "react-dom/client";  // 변경된 부분
import "./index.css"; // 기본 스타일
import App from "./App";
import reportWebVitals from "./reportWebVitals";

// React 18에서 createRoot 사용
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

reportWebVitals();
